<?php
	$nom = trim($_POST['nom']);

	if(isset($_POST['soumettre'])){

	}elseif(isset($_POST['annuler'])){

	}else{

	}
?>