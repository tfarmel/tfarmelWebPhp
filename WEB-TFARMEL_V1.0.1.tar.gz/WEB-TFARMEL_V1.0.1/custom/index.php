	<?php include 'global/header.php'; ?>
	
	<div class="container">
		<div class="row">
			<h1>tfarmel</h1>
			<p style="text-align: justify">					
				Bienvenue <br/>
				Ce site est en construction, merci de votre compréhension et veuillez repasser un peu plus tard!
			</p>
		</div>
	</div>
	

	<?php //include 'global/footer.php'; ?>