<?php include './global/header.php'; ?>
<div class="container">
	<div class="row">
		<h2>Erreur</h2><br/>
		<p>
			Le site est actuellement indisponible ; essayez plus tard. <br/>
			Merci de votre compréhension. <br/>
			<!-- lien vers la nouvelle page -->
			<a href="index.php">Essayer de nouveau</a>
		</p>
	</div>
</div>
<?php include 'global/footer.php'; ?>