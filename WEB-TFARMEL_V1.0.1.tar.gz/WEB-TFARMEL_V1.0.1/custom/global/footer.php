	<footer class="" id="footer">
		<div class="container text-center">
			<small class="copyright">@ 2016 tfarmel - Développé par <a href="http://armeltakoulo.fr" target="_blank">Armel TAKOULO FONKOU</a></small>
		</div>
	</footer>
	<!-- Javascript -->          
    <script type="text/javascript" src="assets/plugins/jquery-1.11.3.min.js"></script>
    <script type="text/javascript" src="assets/plugins/bootstrap/js/bootstrap.min.js"></script>    
    <script type="text/javascript" src="assets/plugins/jquery-rss/dist/jquery.rss.min.js"></script> 
    <!-- custom js -->
    <script type="text/javascript" src="assets/js/main.js"></script>  
</body>
</html>