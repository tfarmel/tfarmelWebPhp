<!DOCTYPE>
<html>
<head>
	<title>TFARMEL</title>
	<!-- Meta -->
	<meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Responsive HTML5 Website Landing Page for Developers">
    <meta name="author" content="Armel TAKOULO FONKOU">  
    <!-- CSS -->
    <link rel="stylesheet" href="assets/plugins/bootstrap/css/bootstrap.min.css"><!-- Global CSS --> 
    <link rel="stylesheet" href="assets/plugins/font-awesome/css/font-awesome.css"><!-- Plugins CSS -->
	<link rel="stylesheet" type="text/css" href="assets/css/general.css"><!-- custom CSS -->
</head>
<body>
	<header id="header" class="">
		<div class="container">
			<div>
				
			</div>
		</div> <!-- // container -->
	</header> <!-- // header  -->